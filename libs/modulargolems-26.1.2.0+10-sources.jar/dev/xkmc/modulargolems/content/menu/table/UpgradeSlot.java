package dev.xkmc.modulargolems.content.menu.table;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.items.SlotItemHandler;
import org.jetbrains.annotations.NotNull;

public class UpgradeSlot extends SlotItemHandler {

	private final GolemUpgradeItemHandler handler;
	private final int index;

	public UpgradeSlot(GolemUpgradeItemHandler itemHandler, int index, int xPosition, int yPosition) {
		super(itemHandler, index, xPosition, yPosition);
		this.handler = itemHandler;
		this.index = index;
	}

	private ItemStack lastReturnedItem = ItemStack.EMPTY;

	@Override
	public @NotNull ItemStack getItem() {
		var newItem = super.getItem();
		if (!lastReturnedItem.equals(newItem))
			lastReturnedItem = newItem;
		return lastReturnedItem;
	}

	public void setChanged() {
		handler.setStackInSlot(index, lastReturnedItem);
	}

	private int lastModification = -1;
	private boolean lastMayPickup;

	@Override
	public boolean mayPickup(Player playerIn) {
		if (lastModification == handler.modification) {
			return lastMayPickup;
		}
		lastModification = handler.modification;
		return lastMayPickup = super.mayPickup(playerIn);
	}

}
